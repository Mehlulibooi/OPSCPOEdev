package com.example.matrixtimetracker;

import java.util.List; // Import List from java.util

public class TimeEntry {
    private final String date;
    private final String startTime;
    private final String endTime;
    private String description;
    private List<String> subtasks;

    public TimeEntry(String date, String startTime, String endTime, String description, List<String> subtasks) {
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;
        this.description = description;
        this.subtasks = subtasks;
    }

    public TimeEntry(String date, String startTime, String endTime) {
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public String getDate() {
        return date;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public String getDescription() {
        return description;
    }

    public List<String> getSubtasks() {
        return subtasks;
    }
}


