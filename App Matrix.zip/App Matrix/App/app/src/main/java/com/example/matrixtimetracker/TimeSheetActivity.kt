package com.example.matrixtimetracker

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class TimeSheetActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_timesheet)

        val textDate = findViewById<TextView>(R.id.textDate)
        val btnStartTime = findViewById<Button>(R.id.btnStartTime)
        val btnEndTime = findViewById<Button>(R.id.btnEndTime)
        val editDescription = findViewById<EditText>(R.id.editDescription)
        val spinnerCategory = findViewById<Spinner>(R.id.spinnerCategory)
        val btnSave = findViewById<Button>(R.id.btnSave)

        // Set onClick listeners for the buttons
        btnStartTime.setOnClickListener {
            // Handle Start Time button click
        }

        btnEndTime.setOnClickListener {
            // Handle End Time button click
        }

        btnSave.setOnClickListener {
            // Save the time entry
            val description = editDescription.text.toString()
            val category = spinnerCategory.selectedItem.toString()
            // Implement saving logic here
        }
    }
}
