package com.example.matrixtimetracker

import android.net.Uri

data class TimeEntry(
    val date: String,
    val startTime: String,
    val endTime: String,
    val description: String,
    val category: String,
    val photoUri: Uri? = null
)
