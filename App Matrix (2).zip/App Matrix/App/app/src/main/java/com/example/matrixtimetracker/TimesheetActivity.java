package com.example.matrixtimetracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import androidx.annotation.NonNull;





public class TimesheetActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private TimesheetAdapter adapter;
    private List<TimeEntry> timeEntries;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timesheet);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        timeEntries = new ArrayList<>();
        // Add dummy data
        timeEntries.add(new TimeEntry("2024-05-01", "09:00 AM", "05:00 PM"));
        timeEntries.add(new TimeEntry("2024-05-02", "08:30 AM", "04:30 PM"));

        adapter = new TimesheetAdapter(timeEntries);
        recyclerView.setAdapter(adapter);
    }
}

class TimesheetAdapter extends RecyclerView.Adapter<TimesheetAdapter.ViewHolder> {

    private final List<TimeEntry> timeEntries;

    public TimesheetAdapter(List<TimeEntry> timeEntries) {
        this.timeEntries = timeEntries;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_timesheet_entry, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TimeEntry entry = timeEntries.get(position);
        holder.textDate.setText(entry.getDate());
        // Bind other data to TextViews
    }

    @Override
    public int getItemCount() {
        return timeEntries.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textDate;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textDate = itemView.findViewById(R.id.textDate);
            // Initialize other TextViews
        }
    }
}

