package com.example.matrixtimetracker

data class UserData(
    val id: String? = null,
    val username: String? = null,
    val password: String? = null,
)
