package com.example.matrixtimetracker

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.matrixtimetracker.databinding.ActivityBarChartBinding
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry

class BarChartActivity : AppCompatActivity() {
    private var _binding: ActivityBarChartBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityBarChartBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val barData = generateBarData(barSet)
        val barDataHorz = generateBarData(barSetHorz)

        binding.barChartVer.apply {
            data = barData
            animateY(animationDuration.toInt())
        }

        binding.barChartHorz.apply {
            data = barDataHorz
            animateX(animationDuration.toInt())
        }
    }

    private fun generateBarData(barSet: List<Pair<String, Float>>): BarData {
        val entries = barSet.mapIndexed { index, pair -> BarEntry(index.toFloat(), pair.second) }
        val dataSet = BarDataSet(entries, "Goals")
        return BarData(dataSet)
    }

    companion object {
        private val barSet = listOf(
            "Goal1" to 4F,
            "Goal2" to 5F,
            "Goal3" to 6F,
            "Goal4" to 7F,
            "Goal5" to 8F,
            "Goal6" to 9F
        )

        private val barSetHorz = listOf(
            "Goal1" to 4F,
            "Goal2" to 5F,
            "Goal3" to 6F,
            "Goal4" to 7F,
            "Goal5" to 8F
        )

        private const val animationDuration = 1000L
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}