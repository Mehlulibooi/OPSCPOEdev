package com.example.matrixtimetracker

data class ProjectData(
     val projectName: String? = null,
     val projectCategory: String? = null,
     val projectDesc: String? = null,
     val projectDate: String? = null
){}
