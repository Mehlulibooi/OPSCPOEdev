package com.example.matrixtimetracker

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.matrixtimetracker.databinding.ActivityLoginBinding
import com.example.matrixtimetracker.databinding.ActivityUploadBinding
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class UploadActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUploadBinding
    private lateinit var databaseReference: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUploadBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.saveButton.setOnClickListener {
            val projectName = binding.projectName.text.toString()
            val projectCategory = binding.projectCategory.text.toString()
            val projectDesc = binding.projectDesc.text.toString()

            databaseReference = FirebaseDatabase.getInstance().getReference("Project information")
            val projectData = ProjectData(projectName,projectCategory, projectDesc)
            databaseReference.child(projectName).setValue(projectData).addOnSuccessListener{
                binding.projectName.text.clear()
                binding.projectCategory.text.clear()
                binding.projectDesc.text.clear()
                
                Toast.makeText(this,"Saved",Toast.LENGTH_SHORT).show()
                val intent = Intent(this@UploadActivity, TimeSheetActivity::class.java)
                startActivity(intent)
                finish()
            }.addOnFailureListener(){
                Toast.makeText(this,"Failed",Toast.LENGTH_SHORT).show()
            }
        } 
    }
}
