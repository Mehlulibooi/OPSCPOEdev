package com.example.matrixtimetracker

import com.google.firebase.firestore.FirebaseFirestore

class FirestoreManager {

    private val db = FirebaseFirestore.getInstance()

    fun addUser(userData: UserData) {
        db.collection("users")
            .add(userData)
    }

    fun addTimesheetEntry(userId: String, entry: TimesheetEntry) {
        db.collection("users")
            .document(userId)
            .collection("timesheet")
            .add(entry)
    }

    fun setUserGoals(userId: String, goals: UserGoals) {
        db.collection("users")
            .document(userId)
            .update("goals", goals)
    }

    fun getUser(userId: String) {
        db.collection("users")
            .document(userId)
            .get()
            .addOnSuccessListener { document ->
                if (document != null) {
                    val userData = document.toObject(UserData::class.java)
                    // Handle user data
                }
            }
    }

    fun getTimesheet(userId: String) {
        db.collection("users")
            .document(userId)
            .collection("timesheet")
            .get()
            .addOnSuccessListener { result ->
                for (document in result) {
                    val entry = document.toObject(TimesheetEntry::class.java)
                    // Handle timesheet entry
                }
            }
    }

    fun getUserGoals(userId: String) {
        db.collection("users")
            .document(userId)
            .get()
            .addOnSuccessListener { document ->
                if (document != null) {
                    val userGoals = document.toObject(UserGoals::class.java)
                    // Handle user goals
                }
            }
    }

}
