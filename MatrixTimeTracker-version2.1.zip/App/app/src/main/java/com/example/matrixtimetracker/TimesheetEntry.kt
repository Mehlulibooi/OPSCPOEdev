package com.example.matrixtimetracker

data class TimesheetEntry(
    val date: String = "",
    val startTime: String = "",
    val endTime: String = "",
    val category: String = ""
)