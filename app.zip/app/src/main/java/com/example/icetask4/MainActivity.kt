import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.icetask4.ExcuseGenerator
import com.example.icetask4.R

class MainActivity : AppCompatActivity() {

    private lateinit var excuseGenerator: ExcuseGenerator
    private lateinit var excuseTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        excuseGenerator = ExcuseGenerator()
        excuseTextView = findViewById(R.id.excuseTextView)

        val generateButton: Button = findViewById(R.id.generateButton)
        generateButton.setOnClickListener {
            val excuse = excuseGenerator.generateExcuse()
            excuseTextView.text = excuse
        }
    }
}
