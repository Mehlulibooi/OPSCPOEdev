package com.example.icetask4

import kotlin.random.Random

class ExcuseGenerator {
    private val excuses = listOf(
        "My dog ate my homework",
        "I woke up late",
        "Just for just for control",
        "I forgot dude i swear",
        "Yohh",
        "Type shii"
    )

    fun generateExcuse(): String {
        val randomIndex = Random.nextInt(excuses.size)
        return excuses[randomIndex]
    }
}
