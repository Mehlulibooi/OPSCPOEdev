package com.example.matrixtimetracker

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.example.matrixtimetracker.databinding.ActivityBarChartBinding
import com.github.mikephil.charting.components.LimitLine
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry

class BarChartActivity : AppCompatActivity() {
    private lateinit var binding: ActivityBarChartBinding
    private val firestoreManager = FirestoreManager()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBarChartBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val userId = intent.getStringExtra("USER_ID") ?: "default_user_id"

        // Add a user (for demonstration purposes)
        val userData = UserData(name = "John Doe", email = "john.doe@example.com")
        firestoreManager.addUser(userData)

        // Add a timesheet entry (for demonstration purposes)
        val entry = TimesheetEntry(date = "2024-06-11", startTime = "09:00", endTime = "17:00")
        firestoreManager.addTimesheetEntry(userId, entry)

        // Set user goals (for demonstration purposes)
        val goals = UserGoals(minHours = 6f, maxHours = 8f)
        firestoreManager.setUserGoals(userId, goals)

        // Get user data
        firestoreManager.getUser(userId) { userData ->
            if (userData != null) {
                Log.d("BarChartActivity", "User Data: $userData")
            } else {
                Log.e("BarChartActivity", "User not found")
            }
        }

        // Display bar chart and goals
        firestoreManager.getTimesheet(userId) { entries ->
            val dailyHours = calculateDailyHours(entries)
            displayBarChart(dailyHours)
        }

        firestoreManager.getUserGoals(userId) { goals ->
            goals?.let {
                displayGoals(it)
            }
        }
    }

    private fun calculateDailyHours(entries: List<TimesheetEntry>): Map<String, Float> {
        val dailyHours = mutableMapOf<String, Float>()
        entries.forEach { entry ->
            try {
                val date = entry.date
                val startTime = entry.startTime.toFloatOrNull()
                val endTime = entry.endTime.toFloatOrNull()

                if (startTime == null || endTime == null) {
                    Log.e("BarChartActivity", "Invalid time format for entry: $entry")
                    return@forEach
                }

                val hours = endTime - startTime
                dailyHours[date] = dailyHours.getOrDefault(date, 0f) + hours
            } catch (e: Exception) {
                Log.e("BarChartActivity", "Error calculating hours for entry: $entry", e)
            }
        }
        return dailyHours
    }

    private fun displayBarChart(dailyHours: Map<String, Float>) {
        val entries = dailyHours.entries.mapIndexed { index, entry ->
            BarEntry(index.toFloat(), entry.value)
        }
        val dataSet = BarDataSet(entries, "Daily Hours")
        val barData = BarData(dataSet)
        binding.barChart.data = barData
        binding.barChart.invalidate()
    }

    private fun displayGoals(goals: UserGoals) {
        val limitLineMin = LimitLine(goals.minHours, "Min Goal")
        val limitLineMax = LimitLine(goals.maxHours, "Max Goal")
        binding.barChart.axisLeft.apply {
            addLimitLine(limitLineMin)
            addLimitLine(limitLineMax)
        }
    }
}
