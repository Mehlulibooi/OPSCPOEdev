package com.example.matrixtimetracker

import com.google.firebase.firestore.FirebaseFirestore

class FirestoreManager {

    private val db = FirebaseFirestore.getInstance()

    fun addUser(userData: UserData) {
        db.collection("users")
            .add(userData)
    }

    fun addTimesheetEntry(userId: String, entry: TimesheetEntry) {
        db.collection("users")
            .document(userId)
            .collection("timesheet")
            .add(entry)
    }

    fun setUserGoals(userId: String, goals: UserGoals) {
        db.collection("users")
            .document(userId)
            .update("goals", goals)
    }

    fun getUser(userId: String, callback: (UserData?) -> Unit) {
        db.collection("users")
            .document(userId)
            .get()
            .addOnSuccessListener { document ->
                if (document != null) {
                    val userData = document.toObject(UserData::class.java)
                    callback(userData)
                } else {
                    callback(null)
                }
            }
            .addOnFailureListener {
                callback(null)
            }
    }

    fun getTimesheet(userId: String, callback: (List<TimesheetEntry>) -> Unit) {
        db.collection("users")
            .document(userId)
            .collection("timesheet")
            .get()
            .addOnSuccessListener { result ->
                val entries = result.map { document ->
                    document.toObject(TimesheetEntry::class.java)
                }
                callback(entries)
            }
            .addOnFailureListener {
                callback(emptyList())
            }
    }

    fun getUserGoals(userId: String, callback: (UserGoals?) -> Unit) {
        db.collection("users")
            .document(userId)
            .get()
            .addOnSuccessListener { document ->
                if (document != null) {
                    val userGoals = document.toObject(UserGoals::class.java)
                    callback(userGoals)
                } else {
                    callback(null)
                }
            }
            .addOnFailureListener {
                callback(null)
            }
    }

}
