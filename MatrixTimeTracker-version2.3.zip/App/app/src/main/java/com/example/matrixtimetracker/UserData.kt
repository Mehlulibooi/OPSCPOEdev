package com.example.matrixtimetracker

data class UserData(
    val id: String? = null,
    val name: String = "",
    val email: String = "",
    val username: String? = null,
    val password: String? = null,
    val goals: UserGoals? = null
)


