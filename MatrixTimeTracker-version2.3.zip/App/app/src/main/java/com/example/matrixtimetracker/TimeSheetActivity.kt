package com.example.matrixtimetracker

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton
import android.view.View
import com.example.matrixtimetracker.databinding.ActivityLoginBinding
import com.example.matrixtimetracker.databinding.ActivityTimesheetBinding

class TimeSheetActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTimesheetBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTimesheetBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.CreateProject.setOnClickListener {
            val intent = Intent(this@TimeSheetActivity, UploadActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}