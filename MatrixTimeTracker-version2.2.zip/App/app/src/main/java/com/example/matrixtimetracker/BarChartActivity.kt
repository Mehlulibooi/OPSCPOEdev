package com.example.matrixtimetracker

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.matrixtimetracker.databinding.ActivityBarChartBinding
import com.github.mikephil.charting.components.LimitLine
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry

class BarChartActivity : AppCompatActivity() {
    private lateinit var binding: ActivityBarChartBinding
    private val firestoreHelper = FirestoreHelper()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBarChartBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val userId = "USER_ID_HERE" // Replace with actual user ID

        firestoreHelper.getTimesheetEntries(userId) { entries ->
            val dailyHours = calculateDailyHours(entries)
            displayBarChart(dailyHours)
        }

        firestoreHelper.getUserGoals(userId) { goals ->
            displayGoals(goals)
        }
    }

    private fun calculateDailyHours(entries: List<TimesheetEntry>): Map<String, Float> {
        val dailyHours = mutableMapOf<String, Float>()
        entries.forEach { entry ->
            val date = entry.date
            val hours = entry.endTime.toFloat() - entry.startTime.toFloat()
            dailyHours[date] = dailyHours.getOrDefault(date, 0f) + hours
        }
        return dailyHours
    }

    private fun displayBarChart(dailyHours: Map<String, Float>) {
        val entries = dailyHours.mapIndexed { index, entry ->
            BarEntry(index.toFloat(), entry.value)
        }
        val dataSet = BarDataSet(entries, "Daily Hours")
        val barData = BarData(dataSet)
        binding.barChart.data = barData
        binding.barChart.invalidate()
    }

    private fun displayGoals(goals: UserGoals) {
        // Display min and max goals on the chart
        val limitLineMin = LimitLine(goals.minHours, "Min Goal")
        val limitLineMax = LimitLine(goals.maxHours, "Max Goal")
        binding.barChart.axisLeft.apply {
            addLimitLine(limitLineMin)
            addLimitLine(limitLineMax)
        }
    }
}

