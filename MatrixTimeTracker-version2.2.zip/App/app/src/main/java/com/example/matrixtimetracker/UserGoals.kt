package com.example.matrixtimetracker

data class UserGoals(
    val minHours: Float = 0f,
    val maxHours: Float = 0f
)