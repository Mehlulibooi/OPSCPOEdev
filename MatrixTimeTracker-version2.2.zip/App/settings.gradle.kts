pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://mvnrepository.com/artifact/com.github.PhilJay/MPAndroidChart") }

    }
}

rootProject.name = "MatrixTimeTracker"
include(":app")
